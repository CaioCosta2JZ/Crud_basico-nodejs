const express = require('express');
const router = express.Router();
const{Categoria} = require('../models');

// listar categorias
router.get("/", async (req, res) => {
    const categorias = await Categoria.findAll();
    res.render(
        "base",{
            title: "Categorias",
            view: "categorias/show",
            categorias,
        });
});

//adicionar categoria - form
router.get("/add", async (req, res) => {
    res.render(
        "base",{
            title: "Add Categoria",
            view: "categorias/show",
            categorias,
        });
});

//adicionar categoria - bd
router.post("/add", async (req, res) => {
    await Categoria.create({
        nome: req.body.nome,
    });
    res.redirect("/categorias");
});

//Editar categoria - form
router.get("/edit/:id", async (req, res) => {
    const categoria = await Categoria.findByPk(req.params.id);
    res.render(
        "base",{
            title: "Add Categoria",
            view: "categorias/edit",
            categoria,
        });
});

//editar categoria - bd
router.post("/edit/:id", async (req, res) => {
    await Categoria.update({
        nome: req.body.nome,
    }, {
        where: {id: req.params.id},
    });
    res.redirect("/categorias");
});



